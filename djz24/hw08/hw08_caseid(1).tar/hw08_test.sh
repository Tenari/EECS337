#
#	hw08_test.sh
#
make clean
make
#./calc +symbol < ../hw07/math10.txt
#./calc +symbol < ../hw07/math11.txt
#./calc +symbol < ../hw07/math12.txt
#./calc +symbol < ../hw07/math13.txt
#./calc +symbol < ../hw07/math14.txt
#./calc +symbol < ../hw07/math15.txt
#./calc +symbol < ../hw07/math16.txt
#./calc +symbol < ../hw07/math17.txt
./calc +symbol < ../hw07/math18.txt
./calc +symbol < ../hw07/math19.txt
#./calc +symbol < math20.txt
