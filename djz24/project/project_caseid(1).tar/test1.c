char c;
