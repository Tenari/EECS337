#
#	project_test.sh
#
make clean
make
./ansi_c Code_1_6_1.c > Code_1_6_1.asm
./ansi_c Code_1_6_2.c > Code_1_6_2.asm
./ansi_c Code_1_6_4.cpp > Code_1_6_4.asm
#./ansi_c mustang.c > mustang.asm
