char c = 2;
