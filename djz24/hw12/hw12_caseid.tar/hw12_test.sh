#
#	hw12_test.sh
#
make clean
make
./calc +symbol ../hw09/math21.txt
#./calc +symbol ../hw09/math22.txt
#./calc +symbol ../hw09/math23.txt
#./calc +symbol ../hw10/math24.txt
#./calc +symbol ../hw10/math25.txt
#./calc +symbol ../hw10/math26.txt
