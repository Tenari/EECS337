/*******************************************************************************
*
* FILE:		Code_1_6_2.c
*
* DESC:		EECS 337 Homework Assignment 1
*
* AUTHOR:	caseid
*
* DATE:		August 27, 2013
*
* EDIT HISTORY:	
*
*******************************************************************************/
#include	<stdio.h>
/*
 *	main program
 */
int	main( int argc, char *argv[])
{
//	enter the sample code from 1.6.2

/*
 *	print the results
 */
	printf( "w:%d,\tx:%d,\ty:%d,\tz:%d\n", w, x, y, z);
/*
 *	return success
 */
	return 0;
}
