# hw01_test.sh
make clean
make
./Code_1_6_1
./Code_1_6_2
./Code_1_6_4
./Echo +echo < Echo.c
./Echo2 < Echo.c
./Echo2 +echo < Echo2.c
