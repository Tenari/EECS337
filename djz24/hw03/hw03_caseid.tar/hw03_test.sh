# hw03_test.sh
make clean
make
#./ansi_c +debug < ../hw01/Code_1_6_1.c
#./ansi_c +debug < ../hw01/Code_1_6_2.c
./ansi_c +debug < ../hw02/Code_1_6_4.cpp
